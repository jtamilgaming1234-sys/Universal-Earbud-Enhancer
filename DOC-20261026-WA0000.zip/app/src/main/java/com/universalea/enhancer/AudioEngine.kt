package com.universalea.enhancer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Low-latency microphone monitor. Audio is routed to a connected private
 * output device only; built-in speakers are intentionally rejected to reduce
 * acoustic feedback risk.
 */
internal class AudioEngine(
    private val context: Context,
    private val onState: (message: String, running: Boolean, output: String?) -> Unit,
) {
    companion object {
        private const val RATE = 48_000
        private const val FRAMES_PER_BLOCK = 480 // 10 ms at 48 kHz
    }

    private val audioManager = context.getSystemService(AudioManager::class.java)
    private val running = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val dsp = AudioDsp(RATE)
    @Volatile private var stopReason: String? = null
    @Volatile private var selectedOutput: String? = null
    private var worker: Thread? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var focusRequest: AudioFocusRequest? = null
    private var recordingCallback: AudioRecord.AudioRecordingCallback? = null

    fun start(mode: String, volume: Float, bass: Float, mid: Float, treble: Float) {
        dsp.volume = volume
        dsp.bassDb = bass
        dsp.midDb = mid
        dsp.trebleDb = treble
        dsp.noiseReductionEnabled = mode == AudioProcessingService.MODE_NOISE_REDUCTION
        if (running.get()) {
            val modeLabel = if (dsp.noiseReductionEnabled) {
                "Software noise reduction"
            } else {
                "Transparency"
            }
            onState("$modeLabel is active.", true, selectedOutput)
            return
        }
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            onState("Microphone permission is required. Allow it in Android settings and try again.", false, null)
            return
        }

        stopReason = null
        running.set(true)
        worker = Thread({ runAudioLoop(mode) }, "EarbudAudioEngine").apply { start() }
    }

    fun setParameters(volume: Float, bass: Float, mid: Float, treble: Float) {
        dsp.volume = volume
        dsp.bassDb = bass
        dsp.midDb = mid
        dsp.trebleDb = treble
    }

    fun stop(reason: String? = null) {
        if (reason != null) stopReason = reason
        running.set(false)
        val thread = worker
        if (thread != null && thread !== Thread.currentThread()) {
            thread.join(700)
        }
    }

    private fun runAudioLoop(mode: String) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        try {
            if (!requestAudioFocus()) {
                throw AudioSetupException("Audio focus is unavailable. Pause other audio and try again.")
            }

            val minRecordBytes = AudioRecord.getMinBufferSize(
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
            )
            val minTrackBytes = AudioTrack.getMinBufferSize(
                RATE,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT,
            )
            if (minRecordBytes <= 0 || minTrackBytes <= 0) {
                throw AudioSetupException("This device does not support the requested 48 kHz audio format.")
            }

            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val inputFormat = AudioFormat.Builder()
                .setSampleRate(RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val outputFormat = AudioFormat.Builder()
                .setSampleRate(RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .build()

            val builtTrack = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(outputFormat)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(max(minTrackBytes * 2, FRAMES_PER_BLOCK * 4 * 4))
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            track = builtTrack

            val builtRecord = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(inputFormat)
                .setBufferSizeInBytes(max(minRecordBytes * 2, FRAMES_PER_BLOCK * 2 * 4))
                .build()
            record = builtRecord

            registerMicrophoneSilenceCallback(builtRecord)
            builtTrack.setVolume(0f)
            builtTrack.play()
            val silence = ShortArray(FRAMES_PER_BLOCK * 2)
            val silentWrite = builtTrack.write(silence, 0, silence.size, AudioTrack.WRITE_BLOCKING)
            if (silentWrite < 0) {
                throw AudioSetupException("Android could not initialize the headphone output.")
            }
            val routeDeadline = System.currentTimeMillis() + 1_500
            var routed = builtTrack.routedDevice
            while (
                running.get() &&
                (routed == null || !isPrivateOutput(routed)) &&
                System.currentTimeMillis() < routeDeadline
            ) {
                Thread.sleep(25)
                routed = builtTrack.routedDevice
            }
            if (routed == null || !isPrivateOutput(routed)) {
                throw AudioSetupException(
                    "No headphone output is selected. Choose Bluetooth earbuds or wired headphones in Android's media output switcher and try again. Phone speakers are blocked.",
                )
            }
            builtTrack.setVolume(1f)
            builtRecord.startRecording()

            selectedOutput = deviceName(routed)
            onState(
                if (mode == AudioProcessingService.MODE_NOISE_REDUCTION) {
                    "Experimental software noise reduction is on. This is not hardware ANC."
                } else {
                    "Transparency monitoring is on. Keep playback at a comfortable level."
                },
                true,
                selectedOutput,
            )

            val input = ShortArray(FRAMES_PER_BLOCK)
            val output = ShortArray(FRAMES_PER_BLOCK * 2)
            while (running.get()) {
                val routed = builtTrack.routedDevice
                if (routed == null || !isPrivateOutput(routed)) {
                    val destination = routed?.let(::deviceName) ?: "an unknown route"
                    stopReason = "Audio output changed to $destination. Processing stopped to prevent speaker feedback."
                    break
                }
                if (audioManager.isMicrophoneMute) {
                    stopReason = "Android microphone access is muted. Turn microphone access back on to resume."
                    break
                }

                val read = builtRecord.read(input, 0, input.size, AudioRecord.READ_BLOCKING)
                if (read < 0) {
                    stopReason = "Microphone read failed (code $read). Try reconnecting your audio device."
                    break
                }
                if (read == 0) continue

                dsp.process(input, read, output)
                val written = builtTrack.write(
                    output,
                    0,
                    read * 2,
                    AudioTrack.WRITE_BLOCKING,
                )
                if (written < 0) {
                    stopReason = "Audio output failed (code $written). Check the connected device."
                    break
                }
            }
        } catch (error: SecurityException) {
            stopReason = "Android blocked microphone or Bluetooth access. Check app permissions and try again."
        } catch (error: AudioSetupException) {
            stopReason = error.message ?: "Audio processing could not start."
        } catch (error: IllegalStateException) {
            stopReason = "The audio device could not start. Reconnect the earbuds and try again."
        } catch (error: Exception) {
            stopReason = "Audio processing stopped: ${error.localizedMessage ?: error.javaClass.simpleName}"
        } finally {
            running.set(false)
            releaseAudio()
            val reason = stopReason
            if (reason != null) {
                onState(reason, false, selectedOutput)
            } else {
                onState("Audio processing is off.", false, selectedOutput)
            }
            selectedOutput = null
            worker = null
        }
    }

    private fun requestAudioFocus(): Boolean {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(attributes)
            .setAcceptsDelayedFocusGain(false)
            .setOnAudioFocusChangeListener { change ->
                if (change <= AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    stopReason = "Audio was interrupted by another app or system event. Tap a mode to resume."
                    running.set(false)
                }
            }
            .build()
        focusRequest = request
        return audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun registerMicrophoneSilenceCallback(audioRecord: AudioRecord) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val callback = object : AudioRecord.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: List<android.media.AudioRecordingConfiguration>) {
                if (configs.any { it.isClientSilenced }) {
                    stopReason = "Android has silenced microphone input. Check system microphone access."
                    running.set(false)
                }
            }
        }
        recordingCallback = callback
        audioRecord.registerAudioRecordingCallback(callback, mainHandler)
    }

    private fun releaseAudio() {
        recordingCallback?.let { callback ->
            try {
                record?.unregisterAudioRecordingCallback(callback)
            } catch (_: Exception) {
                // The recorder may already have been released by Android.
            }
        }
        recordingCallback = null

        try {
            record?.stop()
        } catch (_: Exception) {
            // A partially initialized recorder may not have entered recording.
        }
        try {
            record?.release()
        } catch (_: Exception) {
            // Best-effort cleanup.
        }
        record = null

        try {
            track?.pause()
            track?.flush()
            track?.release()
        } catch (_: Exception) {
            // Best-effort cleanup.
        }
        track = null

        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    private fun isPrivateOutput(device: AudioDeviceInfo): Boolean {
        return isBluetoothOutput(device) || isWiredOutput(device)
    }

    private fun isBluetoothOutput(device: AudioDeviceInfo): Boolean {
        return device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                device.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
    }

    private fun isWiredOutput(device: AudioDeviceInfo): Boolean {
        return device.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            device.type == AudioDeviceInfo.TYPE_USB_HEADSET
    }

    private fun deviceName(device: AudioDeviceInfo): String {
        return try {
            device.productName.toString().takeIf { it.isNotBlank() } ?: "Connected headphones"
        } catch (_: SecurityException) {
            "Connected headphones"
        }
    }

    private class AudioSetupException(message: String) : Exception(message)
}
