package com.universalea.enhancer

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity(), AudioProcessingService.Observer {
    companion object {
        private const val REQUEST_PERMISSIONS = 71
        private const val PREFS = "audio_settings"
    }

    private val audioManager by lazy { getSystemService(AudioManager::class.java) }
    private val preferences by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private lateinit var micStatus: TextView
    private lateinit var bluetoothStatus: TextView
    private lateinit var outputStatus: TextView
    private lateinit var processingStatus: TextView
    private lateinit var message: TextView
    private lateinit var volumeValue: TextView
    private lateinit var volumeSeekBar: SeekBar
    private lateinit var bassSeekBar: SeekBar
    private lateinit var midSeekBar: SeekBar
    private lateinit var trebleSeekBar: SeekBar
    private var service: AudioProcessingService? = null
    private var bound = false
    private var pendingMode: String? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as? AudioProcessingService.LocalBinder ?: return
            service = localBinder.service()
            service?.setObserver(this@MainActivity)
            pendingMode?.let { mode ->
                pendingMode = null
                service?.startProcessing(mode, currentVolume(), currentBass(), currentMid(), currentTreble())
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service?.setObserver(null)
            service = null
            bound = false
            renderProcessingStatus(AudioServiceState("Audio service stopped.", false, null, null))
        }
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            refreshDeviceStatus()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            refreshDeviceStatus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.background)
        window.navigationBarColor = getColor(R.color.background)
        buildInterface()
        audioManager.registerAudioDeviceCallback(deviceCallback, null)
        bindExistingService()
        refreshPermissionStatus()
        refreshDeviceStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
        refreshDeviceStatus()
    }

    override fun onDestroy() {
        audioManager.unregisterAudioDeviceCallback(deviceCallback)
        if (bound) {
            service?.setObserver(null)
            unbindService(connection)
            bound = false
        }
        super.onDestroy()
    }

    override fun onAudioServiceState(state: AudioServiceState) {
        runOnUiThread { renderProcessingStatus(state) }
    }

    private fun buildInterface() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(getColor(R.color.background))
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(30))
        }
        scroll.addView(content)

        content.addView(label("UNIVERSAL EARBUD ENHANCER", 12f, getColor(R.color.accent), true))
        content.addView(space(9))
        content.addView(label("Hear your surroundings.", 28f, getColor(R.color.text_primary), true))
        content.addView(space(7))
        content.addView(label(
            "A phone-mic monitor for compatible headphones. Keep the volume low when testing.",
            15f,
            getColor(R.color.text_secondary),
        ))
        content.addView(space(22))

        val statusCard = card()
        content.addView(statusCard)
        statusCard.addView(label("DEVICE STATUS", 12f, getColor(R.color.text_secondary), true))
        statusCard.addView(space(12))
        micStatus = statusLine(statusCard, "Microphone", "Checking permission…")
        bluetoothStatus = statusLine(statusCard, "Bluetooth", "Checking connection…")
        outputStatus = statusLine(statusCard, "Audio output", "Not active")
        processingStatus = statusLine(statusCard, "Processing", "Off")
        content.addView(space(16))

        val transparencyCard = card()
        content.addView(transparencyCard)
        transparencyCard.addView(label("TRANSPARENCY", 18f, getColor(R.color.text_primary), true))
        transparencyCard.addView(space(6))
        transparencyCard.addView(label(
            "Passes live microphone audio to your headphones. This does not control earbud hardware.",
            14f,
            getColor(R.color.text_secondary),
        ))
        transparencyCard.addView(space(13))
        addActionButton(transparencyCard, "Enable transparency", getColor(R.color.accent)) {
            requestAndStart(AudioProcessingService.MODE_TRANSPARENCY)
        }

        content.addView(space(12))
        val reductionCard = card()
        content.addView(reductionCard)
        reductionCard.addView(label("NOISE REDUCTION", 18f, getColor(R.color.text_primary), true))
        reductionCard.addView(space(6))
        reductionCard.addView(label(
            "Experimental software noise gate. It may reduce quiet background noise and affect quiet speech. " +
                "It is not genuine hardware ANC.",
            14f,
            getColor(R.color.text_secondary),
        ))
        reductionCard.addView(space(13))
        addActionButton(reductionCard, "Enable software noise reduction", getColor(R.color.surface_variant)) {
            requestAndStart(AudioProcessingService.MODE_NOISE_REDUCTION)
        }

        content.addView(space(12))
        val controlsCard = card()
        content.addView(controlsCard)
        controlsCard.addView(label("AMBIENT AUDIO LEVEL", 17f, getColor(R.color.text_primary), true))
        controlsCard.addView(space(8))
        volumeValue = label("", 14f, getColor(R.color.accent), true)
        controlsCard.addView(volumeValue)
        volumeSeekBar = SeekBar(this).apply {
            max = 100
            progress = preferences.getInt("volume", 30)
            setOnSeekBarChangeListener(seekListener { progress ->
                preferences.edit().putInt("volume", progress).apply()
                volumeValue.text = "$progress% — keep it comfortable"
                pushParameters()
            })
        }
        volumeValue.text = "${volumeSeekBar.progress}% — keep it comfortable"
        controlsCard.addView(volumeSeekBar)
        controlsCard.addView(space(16))
        controlsCard.addView(label("EQUALIZER", 17f, getColor(R.color.text_primary), true))
        controlsCard.addView(space(3))
        controlsCard.addView(label(
            "Small tone adjustments only; output is softly limited to reduce clipping.",
            13f,
            getColor(R.color.text_secondary),
        ))
        controlsCard.addView(space(8))
        bassSeekBar = eqControl(controlsCard, "Bass", "bass")
        midSeekBar = eqControl(controlsCard, "Midrange", "mid")
        trebleSeekBar = eqControl(controlsCard, "Treble", "treble")
        controlsCard.addView(space(10))
        addActionButton(controlsCard, "Reset equalizer", getColor(R.color.surface_variant)) {
            preferences.edit()
                .putInt("bass", 12)
                .putInt("mid", 12)
                .putInt("treble", 12)
                .apply()
            bassSeekBar.progress = 12
            midSeekBar.progress = 12
            trebleSeekBar.progress = 12
            pushParameters()
        }

        content.addView(space(12))
        val stopButton = button("Turn audio processing off", getColor(R.color.error), getColor(R.color.background))
        stopButton.setOnClickListener {
            pendingMode = null
            service?.stopProcessing() ?: run {
                stopService(Intent(this, AudioProcessingService::class.java))
                renderProcessingStatus(AudioServiceState("Audio processing is off.", false, null, null))
            }
        }
        content.addView(stopButton, matchWrap())

        content.addView(space(14))
        message = label(
            "Microphone audio is processed on this device. It is sent to the selected headphone output while a mode is on.",
            13f,
            getColor(R.color.text_secondary),
        )
        content.addView(message)
        setContentView(scroll)
    }

    private fun eqControl(parent: LinearLayout, title: String, key: String): SeekBar {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val name = label("$title", 14f, getColor(R.color.text_primary), true)
        line.addView(name, LinearLayout.LayoutParams(0, dp(32), 1f))
        val value = label("0 dB", 13f, getColor(R.color.text_secondary))
        value.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        line.addView(value, LinearLayout.LayoutParams(dp(60), dp(32)))
        parent.addView(line)

        val seekBar = SeekBar(this).apply {
            max = 24
            progress = preferences.getInt(key, 12).coerceIn(0, 24)
            setOnSeekBarChangeListener(seekListener { progress ->
                val decibels = progress - 12
                value.text = "${if (decibels > 0) "+" else ""}${decibels} dB"
                preferences.edit().putInt(key, progress).apply()
                pushParameters()
            })
        }
        value.text = "${if (seekBar.progress > 12) "+" else ""}${seekBar.progress - 12} dB"
        parent.addView(seekBar)
        return seekBar
    }

    private fun requestAndStart(mode: String) {
        val missing = requiredRuntimePermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            pendingMode = mode
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
            message.text = "Allow microphone access and Bluetooth device access to start. Notification access is recommended."
            return
        }
        startMode(mode)
    }

    private fun requiredRuntimePermissions(): List<String> {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        return permissions
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_PERMISSIONS) return
        val micGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val bluetoothGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        refreshPermissionStatus()
        if (!micGranted || !bluetoothGranted) {
            pendingMode = null
            message.text = if (!micGranted) {
                "Microphone permission is needed for live audio. You can allow it in Android app settings."
            } else {
                "Bluetooth permission is needed to identify and route to connected earbuds."
            }
            return
        }
        val mode = pendingMode
        pendingMode = null
        if (mode != null) startMode(mode)
    }

    private fun startMode(mode: String) {
        pendingMode = mode
        val intent = Intent(this, AudioProcessingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        if (!bound) {
            bound = bindService(intent, connection, Context.BIND_AUTO_CREATE)
            if (!bound) {
                pendingMode = null
                message.text = "Android could not start the audio service. Restart the app and try again."
            }
        } else {
            val activeService = service
            if (activeService != null) {
                activeService.startProcessing(mode, currentVolume(), currentBass(), currentMid(), currentTreble())
                pendingMode = null
            }
        }
        message.text = "Starting microphone monitoring. Android may take a moment to connect the audio route."
    }

    private fun bindExistingService() {
        val intent = Intent(this, AudioProcessingService::class.java)
        bound = bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun pushParameters() {
        service?.setParameters(currentVolume(), currentBass(), currentMid(), currentTreble())
    }

    private fun currentVolume() = volumeSeekBar.progress / 100f
    private fun currentBass() = (bassSeekBar.progress - 12).toFloat()
    private fun currentMid() = (midSeekBar.progress - 12).toFloat()
    private fun currentTreble() = (trebleSeekBar.progress - 12).toFloat()

    private fun refreshPermissionStatus() {
        if (!::micStatus.isInitialized) return
        val granted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        micStatus.text = if (granted) "Allowed" else "Permission needed"
        micStatus.setTextColor(getColor(if (granted) R.color.accent else R.color.warning))
    }

    private fun refreshDeviceStatus() {
        if (!::bluetoothStatus.isInitialized) return
        try {
            val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val bluetooth = outputs.firstOrNull { isBluetoothOutput(it) }
            bluetoothStatus.text = bluetooth?.let { "Connected · ${safeDeviceName(it)}" } ?: "No Bluetooth earbuds detected"
            bluetoothStatus.setTextColor(getColor(if (bluetooth != null) R.color.accent else R.color.text_secondary))
            if (::processingStatus.isInitialized && processingStatus.text == "Off") {
                val availableOutput = bluetooth ?: outputs.firstOrNull {
                    it.isSink && (
                        it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                            it.type == AudioDeviceInfo.TYPE_USB_HEADSET
                        )
                }
                outputStatus.text = availableOutput?.let {
                    "Available: ${safeDeviceName(it)}"
                } ?: "No private output detected"
            }
        } catch (_: SecurityException) {
            bluetoothStatus.text = "Bluetooth permission needed"
            bluetoothStatus.setTextColor(getColor(R.color.warning))
            if (::processingStatus.isInitialized && processingStatus.text == "Off") {
                outputStatus.text = "Bluetooth permission needed"
            }
        }
    }

    private fun renderProcessingStatus(state: AudioServiceState) {
        if (!::processingStatus.isInitialized) return
        processingStatus.text = if (state.running) "On" else "Off"
        processingStatus.setTextColor(getColor(if (state.running) R.color.accent else R.color.text_secondary))
        outputStatus.text = state.output ?: if (state.running) "Selecting device…" else "Not active"
        if (!state.running && state.message.isNotBlank() && state.message != "Ready when you are." && state.message != "Audio processing is off.") {
            message.text = state.message
            message.setTextColor(getColor(R.color.warning))
        } else if (state.running) {
            message.text = state.message
            message.setTextColor(getColor(R.color.text_secondary))
        }
        if (!state.running) refreshDeviceStatus()
    }

    private fun statusLine(parent: LinearLayout, title: String, status: String): TextView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val key = label(title, 14f, getColor(R.color.text_secondary))
        row.addView(key, LinearLayout.LayoutParams(0, dp(29), 1f))
        val value = label(status, 14f, getColor(R.color.text_primary), true)
        value.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        row.addView(value, LinearLayout.LayoutParams(0, dp(29), 1.6f))
        parent.addView(row)
        return value
    }

    private fun addActionButton(parent: LinearLayout, text: String, backgroundColor: Int, action: () -> Unit) {
        val actionButton = button(text, backgroundColor, getColor(R.color.text_primary))
        actionButton.setOnClickListener { action() }
        parent.addView(actionButton, matchWrap())
    }

    private fun button(text: String, backgroundColor: Int, textColor: Int) =
        Button(this).apply {
            this.text = text
            setTextColor(textColor)
            textSize = 14f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(backgroundColor, 14)
            minHeight = dp(52)
            stateListAnimator = null
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(16), dp(17), dp(16))
        background = rounded(getColor(R.color.surface), 18)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(dp(2).toFloat(), 1f)
        }

    private fun space(heightDp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(heightDp))
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT,
    )

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun seekListener(onProgress: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = onProgress(progress)
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    private fun isBluetoothOutput(device: AudioDeviceInfo) =
        device.isSink && (
            device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    device.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
            )

    private fun safeDeviceName(device: AudioDeviceInfo): String {
        return try {
            device.productName.toString().takeIf { it.isNotBlank() } ?: "Headphones"
        } catch (_: SecurityException) {
            "Headphones"
        }
    }
}
