package com.universalea.enhancer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.tanh

/**
 * Small, bounded-gain audio processor for a prototype.
 *
 * Noise reduction is deliberately a simple adaptive gate, not ANC. It reduces
 * low-level background sound and may also clip quiet speech.
 */
internal class AudioDsp(
    private val sampleRate: Int,
) {
    @Volatile
    var volume: Float = 0.30f

    @Volatile
    var bassDb: Float = 0f

    @Volatile
    var midDb: Float = 0f

    @Volatile
    var trebleDb: Float = 0f

    @Volatile
    var noiseReductionEnabled: Boolean = false

    private var lowState = 0f
    private var upperState = 0f
    private var noiseFloor = 0.008f
    private var gateGain = 1f

    private val lowCoefficient = onePoleCoefficient(220f, sampleRate)
    private val upperCoefficient = onePoleCoefficient(2_800f, sampleRate)

    fun process(input: ShortArray, sampleCount: Int, stereoOutput: ShortArray) {
        val bassGain = decibelsToGain(bassDb)
        val midGain = decibelsToGain(midDb)
        val trebleGain = decibelsToGain(trebleDb)
        val outputVolume = volume.coerceIn(0f, 1f)
        val reduceNoise = noiseReductionEnabled

        for (i in 0 until sampleCount) {
            val sample = input[i] / 32768f
            lowState += lowCoefficient * (sample - lowState)
            upperState += upperCoefficient * (sample - upperState)

            val bass = lowState
            val treble = sample - upperState
            val mid = sample - bass - treble
            var processed = bass * bassGain + mid * midGain + treble * trebleGain

            if (reduceNoise) {
                val level = abs(processed)
                if (level < noiseFloor * 2.5f) {
                    noiseFloor += (level - noiseFloor) * 0.0015f
                } else {
                    noiseFloor = max(0.002f, noiseFloor * 0.99995f)
                }

                val threshold = max(0.012f, noiseFloor * 2.8f)
                val targetGain = if (level < threshold) {
                    max(0.12f, level / threshold)
                } else {
                    1f
                }
                val smoothing = if (targetGain < gateGain) 0.12f else 0.015f
                gateGain += (targetGain - gateGain) * smoothing
                processed *= gateGain
            } else {
                gateGain = 1f
            }

            // A fixed pre-attenuation plus a soft limiter prevents EQ boosts
            // from creating unbounded digital peaks.
            val limited = tanh(processed * 0.58f) * 0.78f * outputVolume
            val pcm = (limited * 32767f).toInt().coerceIn(-32768, 32767).toShort()
            val outputIndex = i * 2
            stereoOutput[outputIndex] = pcm
            stereoOutput[outputIndex + 1] = pcm
        }
    }

    private fun decibelsToGain(db: Float): Float {
        return 10f.pow(db.coerceIn(-9f, 9f) / 20f)
    }

    private fun onePoleCoefficient(cutoffHz: Float, rate: Int): Float {
        val ratio = (2.0 * Math.PI * cutoffHz / rate).coerceIn(0.0, 1.0)
        return ratio.toFloat()
    }
}
