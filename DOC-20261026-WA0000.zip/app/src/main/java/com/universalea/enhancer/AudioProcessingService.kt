package com.universalea.enhancer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.graphics.Color
import android.graphics.drawable.Icon

data class AudioServiceState(
    val message: String,
    val running: Boolean,
    val mode: String?,
    val output: String?,
)

class AudioProcessingService : Service() {
    companion object {
        const val MODE_TRANSPARENCY = "transparency"
        const val MODE_NOISE_REDUCTION = "noise_reduction"

        private const val CHANNEL_ID = "audio_processing"
        private const val NOTIFICATION_ID = 4102
        private const val ACTION_STOP = "com.universalea.enhancer.STOP"
    }

    interface Observer {
        fun onAudioServiceState(state: AudioServiceState)
    }

    inner class LocalBinder : Binder() {
        fun service(): AudioProcessingService = this@AudioProcessingService
    }

    private val binder = LocalBinder()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var observer: Observer? = null
    private var engine: AudioEngine? = null
    private var currentMode: String? = null
    private var currentState = AudioServiceState("Ready when you are.", false, null, null)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        engine = AudioEngine(applicationContext) { message, running, output ->
            mainHandler.post {
                currentState = AudioServiceState(message, running, currentMode, output)
                observer?.onAudioServiceState(currentState)
                updateNotification(message, running)
                if (!running && currentMode != null) currentMode = null
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopProcessing()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification("Microphone processing is ready.", false))
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    fun setObserver(value: Observer?) {
        observer = value
        value?.onAudioServiceState(currentState)
    }

    fun startProcessing(mode: String, volume: Float, bass: Float, mid: Float, treble: Float) {
        if (mode != MODE_TRANSPARENCY && mode != MODE_NOISE_REDUCTION) return
        currentMode = mode
        startForeground(
            NOTIFICATION_ID,
            buildNotification(
                if (mode == MODE_NOISE_REDUCTION) "Experimental noise reduction is starting." else "Transparency monitoring is starting.",
                true,
            ),
        )
        currentState = AudioServiceState("Starting audio processing…", true, mode, null)
        observer?.onAudioServiceState(currentState)
        engine?.start(mode, volume, bass, mid, treble)
    }

    fun setParameters(volume: Float, bass: Float, mid: Float, treble: Float) {
        engine?.setParameters(volume, bass, mid, treble)
    }

    fun stopProcessing() {
        engine?.stop()
        currentMode = null
        currentState = AudioServiceState("Audio processing is off.", false, null, null)
        observer?.onAudioServiceState(currentState)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        engine?.stop()
        engine = null
        observer = null
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Live audio processing",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Shown while Universal Earbud Enhancer uses the microphone."
                setShowBadge(false)
                lightColor = Color.CYAN
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun updateNotification(message: String, running: Boolean) {
        if (running) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(message, true))
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun buildNotification(message: String, running: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        builder
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Universal Earbud Enhancer")
            .setContentText(message)
            .setContentIntent(openApp)
            .setOngoing(running)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)

        if (running) {
            val stopIntent = PendingIntent.getService(
                this,
                1,
                Intent(this, AudioProcessingService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            builder.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Stop",
                    stopIntent,
                ).build(),
            )
        }
        return builder.build()
    }
}
