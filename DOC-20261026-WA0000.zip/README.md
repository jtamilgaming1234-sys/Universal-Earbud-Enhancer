# Universal Earbud Enhancer (Android source project)

This is a native Kotlin Android application project. It is not a website or an
APK. The Replit environment used to create these files has no Java runtime,
Gradle installation, or Android SDK, so an APK could not be compiled or tested
here. Build the source with Android Studio or another Android SDK environment.

## What the prototype does

- Uses the phone microphone for live monitoring and sends the processed signal
  through Android's current media output route to Bluetooth A2DP/BLE or wired
  headphones.
- Uses an Android foreground service with a persistent notification and Stop
  action while monitoring is active.
- Requests microphone and Bluetooth device permissions at runtime and reports
  Android mic mute/silencing, routing failures, focus interruptions, and device
  changes in the app.
- Refuses to start without a private headphone output and stops if playback
  moves to the phone speaker. Android's media audio route is used; the app does
  not take over the system-wide Bluetooth communication route.
- Includes an experimental adaptive software noise gate. It may reduce quiet
  background noise but can affect quiet speech. It is not hardware ANC and
  cannot create true active noise cancellation on unsupported earbuds.
- Provides bass, midrange, treble, and ambient level controls. DSP gain is
  limited and passed through a soft limiter.

## Optional: Build locally with Android Studio

1. Install Android Studio with Android SDK Platform 35, Android Build Tools,
   and JDK 17.
2. Open this project directory in Android Studio. The included Gradle wrapper
   downloads Gradle 8.9 and the required Android Gradle Plugin/Kotlin plugins.
3. The project targets Android 15 APIs and supports Android 8.0+; Android 14 is
   supported.
4. Connect the OPPO F21 Pro 4G with USB debugging enabled. In Android settings,
   allow USB debugging and install the app from Android Studio using **Run**.
5. For a debug APK, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   Android Studio writes it under `app/build/outputs/apk/debug/`.
6. For a distributable release APK, create a signing key in Android Studio and
   use **Build > Generate Signed Bundle / APK**. Keep that signing key private.

From this folder, the equivalent command is:

```sh
./gradlew assembleDebug
```

## Download the project ZIP to an Android phone

In the Replit mobile app, open this project's file tree. Tap the three-dot menu
next to `android/Universal-Earbud-Enhancer-Android-Project.zip` and choose
**Download**. Alternatively, use the three-dot menu next to the `android/`
folder to download the folder as a ZIP. Save it to the phone's Downloads folder
and extract it with the Files app.

## Recommended: Build the APK in the cloud using a phone

This project includes `.github/workflows/build-android-apk.yml`. It builds a
debug APK with GitHub Actions, JDK 17, Android SDK 35, and the included Gradle
wrapper. No signing key or secret is required for a debug APK.

1. Download this project ZIP and extract it on your Android phone.
2. Create a GitHub repository and place the extracted project contents at the
   repository root (the `.github/` folder must be at the root alongside
   `app/`, `gradlew`, and `settings.gradle.kts`).
3. Commit or upload the files. GitHub Actions builds the APK on each push.
   You can also open the repository's **Actions** tab, choose **Build Android
   APK**, and tap **Run workflow**.
4. Open the completed run, download the
   `Universal-Earbud-Enhancer-debug-APK` artifact, and extract that downloaded
   artifact ZIP on your phone. It contains `app-debug.apk`.
5. Tap `app-debug.apk` to install. If Android asks, allow your browser or file
   manager to install unknown apps.

The generated debug APK is for personal testing. A Play Store or distributable
release requires a separately signed release build.

## Test on the OPPO

1. Pair and connect Bluetooth earbuds in Android settings. If needed, select
   them in Android's media output switcher before opening the app.
2. Grant microphone and Bluetooth permissions when prompted. Notification
   permission is recommended so the ongoing processing notification is visible.
3. Start at a low ambient level. Confirm the status shows the earbuds as the
   output and use the notification Stop action to end monitoring.
4. Test screen-off behavior, incoming calls, notification interruptions, earbud
   disconnect/reconnect, Android's microphone privacy toggle, and permission
   revocation.

## Important limitations

- Bluetooth codec buffering is controlled by Android and the earbuds. The
  prototype requests low-latency audio but cannot guarantee low end-to-end
  Bluetooth latency. Many A2DP earbuds add noticeable delay.
- The app does not promise echo cancellation. Only private headset outputs are
  allowed to reduce feedback risk.
- Android/OEM restrictions may silence or interrupt microphone capture. The
  app stops on audio-focus loss and reports known microphone silencing.
- Transparency depends on the phone microphone, headset route, and device
  latency. It is not a replacement for hearing protection or situational
  awareness; use cautiously around traffic and machinery.
